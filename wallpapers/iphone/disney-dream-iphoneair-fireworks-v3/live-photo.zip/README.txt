星河入梦
把童话，留给每一次心动

AI 原创城堡，保留底图烟花纹理，叠加升空、绽放与消散的烟花动画；非官方实拍或活动复刻。
https://disneyparksblog.com/shdl/shanghai-disney-resort-10th-anniversary-celebration/
1260 × 2736 · 3 秒 · 30 fps
photo.jpg 与 motion.mov 是同一张 Live Photo 的配对原件，请保留两者的元数据。
Safari 下载 ZIP 不会自动将它写入 iPhone 相册。此包供保留原件及兼容的导入流程使用，不能直接设置为动态墙纸。
preview.mp4 为动态光影视频，photo.jpg 可单独保存为静态壁纸。
在相册中播放为实况照片不保证 iOS 允许动态锁屏，需真机确认。
